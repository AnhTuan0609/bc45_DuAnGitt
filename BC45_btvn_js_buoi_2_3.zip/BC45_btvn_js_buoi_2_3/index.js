// Bài 1:
document.getElementById('tinh-tien-luong').onclick = function () {
    var luong = +document.getElementById('nhap-luong-mot-ngay').value;
    var soNgayLam = +document.getElementById('so-ngay-lam').value;

    var tongTienLuong = luong * soNgayLam;
    var stringHTML = `${tongTienLuong} là tổng tiền lương của 1 nhân viên`;

    document.getElementById('ket-qua-bai-1').innerHTML = stringHTML;
}


// Bài 2:
document.getElementById('tinh-trung-binh').onclick = function () {
    var so1 = +document.getElementById('so-1').value;
    var so2 = +document.getElementById('so-2').value;
    var so3 = +document.getElementById('so-3').value;
    var so4 = +document.getElementById('so-4').value;
    var so5 = +document.getElementById('so-5').value;

    var giaTriTB = (so1 + so2  + so3 + so4 + so5) / 5;
    var stringHTML = `${giaTriTB} là giá trị trung bình`;

    document.getElementById('ket-qua-bai-2').innerHTML = stringHTML;
}


// Bài 3:
document.getElementById('thanh-tien-Viet').onclick = function(){
    var nhapSoUSD = +document.getElementById('nhapUSD').value;
    
    var quyDoi = nhapSoUSD * 23500;
    var stringHTML = `${quyDoi}VND`;

    document.getElementById('ket-qua-bai-3').innerHTML = stringHTML;
}


// Bài 4:
document.getElementById('dienTich-chuVi').onclick = function(){
    var chieuDai = +document.getElementById('chieu-dai').value;
    var chieuRong = +document.getElementById('chieu-rong').value;

    var dienTich = chieuDai * chieuRong;
    var chuVi = (chieuDai + chieuRong) * 2;

    var stringHTML = `Diện tich: ${dienTich} ; Chu vi: ${chuVi}`;

    document.getElementById('ket-qua-bai-4').innerHTML = stringHTML;
}


// Bài 5:
document.getElementById('tong2KySo').onclick = function(){
    var so = +document.getElementById('kySo').value;

    let so_hang_dv = so % 10;
    let so_hang_chuc = so / 10;

    var tongKySo = so_hang_dv + so_hang_chuc;
    var stringHTML = tongKySo;

    document.getElementById('ket-qua-bai-5').innerHTML = stringHTML;
}