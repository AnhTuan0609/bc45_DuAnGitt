var arrNumber = [];

document.getElementById('btnThemMang').onclick = function () {
    var soNhap = +document.getElementById('nhap-so').value;
    arrNumber.push(soNhap);
    document.getElementById('ket-qua').innerHTML = `[${arrNumber}]`;
    document.getElementById('arrNumber').innerHTML = arrNumber;
}


// Bài 1:
document.getElementById('tinhTongSoDuong').onclick = function () {
    let sum = 0;

    for (let i = 0; i < arrNumber.length; i++) {
        if (arrNumber[i] > 0) {
            sum += arrNumber[i];
        }
    }
    document.getElementById('ket-qua-bai1').innerHTML = sum;
}


// Bài 2:
document.getElementById('demSoDuong').onclick = function () {
    var demSo = 0;
    for (var i = 0; i < arrNumber.length; i++) {
        if (arrNumber[i] > 0) {
            // demSo = arrNumber[i];
            demSo++;
        }
    }
    document.getElementById('ket-qua-bai2').innerHTML = demSo;
}


// Bài 3:
document.getElementById('soNhoNhat').onclick = function () {
    var min = arrNumber[0];

    for (var i = 0; i < arrNumber.length; i++) {
        if (arrNumber[i] < min) {
            min = arrNumber[i];
        }
    }

    document.getElementById('ket-qua-bai3').innerHTML = min;
}


// Bài 4:
document.getElementById('soDuongNhoNhat').onclick = function () {

    var evenMin = arrNumber[0];

    for (var i = 0; i < arrNumber.length; i++) {
        if (arrNumber[i] < evenMin && arrNumber[i] > 0) {
            evenMin = arrNumber[i];
        }
    }

    document.getElementById('ket-qua-bai4').innerHTML = evenMin;
}


// Bài 5:
document.getElementById('soChanCuoiCung').onclick = function () {

    var lastEvenMin = -1;

    for (var i = 0; i < arrNumber.length; i++) {
        if (arrNumber[i] % 2 === 0) {
            lastEvenMin = arrNumber[i];
        }
    }

    document.getElementById('ket-qua-bai5').innerHTML = lastEvenMin;
}


// Bài 6:
document.getElementById('doiCho2GiaTri').onclick = function () {
    var doiChoVitri1 = +document.getElementById('nhap-so-doi-cho1').value;
    var doiChoVitri2 = +document.getElementById('nhap-so-doi-cho2').value;

    var b = arrNumber[doiChoVitri1];
    arrNumber[doiChoVitri1] = arrNumber[doiChoVitri2];
    arrNumber[doiChoVitri2] = b;
    document.getElementById('ket-qua-bai6').innerHTML = arrNumber;
}



// Bài 7:
document.getElementById('sapXepMang').onclick = function () {
    var sapXep = arrNumber;
    sapXep.sort();
    document.getElementById('ket-qua-bai7').innerHTML = sapXep;
}


// Bài 8:
// Hàm kiểm tra xem một số có phải là số nguyên tố hay không
document.getElementById('kiemTraSoNT').onclick = function () {
    function isPrime(arrNumber) {
        if (arrNumber <= 1) {
            return false;
        }
        for (let i = 2; i <= Math.sqrt(arrNumber[i]); i++) {
            if (arrNumber[i] % i === 0) {
                return false;
            }
        }
        return true;
        findFirstPrime();
    }

    // Hàm tìm số nguyên tố đầu tiên trong mảng
    function findFirstPrime(arrNumber) {
        for (let i = 0; i < arrNumber.length; i++) {
            if (isPrime(arrNumber[i])) {
                return arrNumber[i];
            }
        }
        return -1;
    }
    document.getElementById('ket-qua-bai8').innerHTML = arrNumber[i];
}



// Bài 9:
document.getElementById('themSoThuc').onclick = function () {
    var themSo = +document.getElementById('them-so-thuc').value;

    arrNumber.push(themSo);

    var demUoc = 0;
    var soHang = 1;
    for (var i = 0; i < arrNumber.length; i++) {
        while (soHang <= arrNumber[i]) {

            // B3: Khối lệnh
            if (arrNumber[i] % soHang === 0) {
                demUoc++;
            }
            soHang++;
        }

        if (demUoc === 2) {
            var count = arrNumber[i];
            count++;
        }
    }


    document.getElementById('ket-qua-bai9').innerHTML = count;

    document.getElementById('ket-qua-bai9').innerHTML = arrNumber;
    document.getElementById('arrNumber').innerHTML = arrNumber;

}


// Bài 10:
document.getElementById('soSanh').onclick = function () {

    var htmlString = '';
    var soAm = 0;
    var soDuong = 0;
    for (var i = 0; i < arrNumber.length; i++) {
        if (arrNumber[i] >= 0) {
            soDuong++;
        } else if (arrNumber[i] <= 0) {
            soAm++;
        }
    }
    if (soAm > soDuong) {
        htmlString = `số âm nhiều hơn số dương`;
    } else {
        htmlString = `số dương nhiều hơn số âm`;
    }

    document.getElementById('ket-qua-bai10').innerHTML = htmlString;
}

